package Util;

/* Category in businesses, following Json format */

public class Category {
	
	private String alias;
	private String title;
	
	public Category(String alias, String title){
		this.alias = alias;
		this.title = title;
	}
	
	public String getAlias() {
		return alias;
	}
	public String getTitle() {
		return title;
	}
	
}

//
//"categories": [
//               {
//                   "alias": "burgers",
//                   "title": "Burgers"
//               }
//           ],