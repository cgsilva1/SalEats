package Util;

/* Category in businesses, following Json format */

public class Location {
	
	private String address1;
	private String address2;
	private String address3;
	private String city;
	private String zip_code;
	private String country;
	private String state;
	
	
	public Location(String address1, String address2, String address3, String city, String zip_code, String country, String state){
		this.address1 = address1;
		this.address2 = address2;
		this.address3 = address3;
		this.city = city;
		this.zip_code = zip_code;
		this.country = country;
		this.state = state;
	}
	
	/*getter for display address
	 * append all addresses to one string to display
	 * 
	 * */
	public String get_display_address(){
		String address = "";
		if(this.address1 != null && this.address1 != " ") {
			address += address1 + "\n";
		}
		if(this.address2 != null && this.address2 != " ") {
			address += address2 + "\n";
		}
		if(this.address3 != null && this.address3 != ". ") {
			address += address3 + "\n";
		}
		
		return address + city + ", " + state + ", " + zip_code + " "+ country; //format of address 
	}
	
}
