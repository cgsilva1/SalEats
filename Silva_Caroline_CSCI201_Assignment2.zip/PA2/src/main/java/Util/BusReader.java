package Util;

public class BusReader {
	public Business[] businesses;
}
