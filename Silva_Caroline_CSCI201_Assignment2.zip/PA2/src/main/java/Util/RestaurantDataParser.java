package Util;


import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

import java.sql.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.servlet.annotation.WebServlet;

/**
 * A class that pretends to be the Yelp API
 */
@WebServlet("/RestaurantDispatcher")
public class RestaurantDataParser {
    private static Boolean ready = false;
//    public static List<Business> businessList = new ArrayList<Business>();
    public static Business[] BusinessHelper;
    private static BusReader readIn; 
    
    /**
     * Initializes the DB with json data
     *
     * @param responseString the Yelp json string
     * @throws FileNotFoundException 
     */
    public static void Init(String responseString) throws FileNotFoundException {
        
    	if(ready) {
    		return;
    	}
        
        try {
           
            //TODO check if you've done the initialization
//            File file = new File(responseString);
//            System.out.println(file);
//            Scanner sc = new Scanner(file);
//            String temp = "";
//            while (sc.hasNext()) {
//            	temp += sc.nextLine();
//            }
        	
        	InputStream inputStream = RestaurantDataParser.class.getClassLoader().getResourceAsStream("/restaurant_data.json");
        	String text = new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
        
            
            readIn = new Gson().fromJson(text, BusReader.class);
            BusinessHelper = readIn.businesses; 
            
        	
//        	ready = true;
            //TESTING 
//            int counter = 0;
//            for(int i = 0; i < BusinessHelper.length; i++) {
//            	System.out.println(BusinessHelper[i].getName());
//            	counter++;
//            }
//            System.out.println(counter);
            
        	Class.forName("com.mysql.cj.jdbc.Driver"); //load and register JDBC driver for MySQL
        	String db = "jdbc:mysql://localhost:3306/restaurant_data?serverTimezone=UTC";
        	String name = "root";
        	String password = "root";
        	Connection conn = DriverManager.getConnection(db, name, password); //connect to SQL
        	
        	PreparedStatement p;
        	p = conn.prepareStatement("SET SQL_SAFE_UPDATES = 0;"); //safe updates 
        	p.execute();
        	
        	p = conn.prepareStatement("SET FOREIGN_KEY_CHECKS = 0;");
        	p.execute();
        	
        	//CLEAR TABLES 
        	p = conn.prepareStatement("TRUNCATE TABLE Restaurant;");
        	p.execute();
        	
        	p = conn.prepareStatement("TRUNCATE TABLE Rating_details;");
        	p.execute();
        	
        	p = conn.prepareStatement("TRUNCATE TABLE Category;");
        	p.execute();
        	
        	p = conn.prepareStatement("TRUNCATE TABLE Restaurant_details;");
        	p.execute();
        	
        	p = conn.prepareStatement("ALTER TABLE restaurant_data.Category AUTO_INCREMENT = 1;"); //resert incrementing to 1
        	p.execute();
        	
        	int count = 1;
        	
        	for(Business b: BusinessHelper) {
        		p = conn.prepareStatement("INSERT INTO Rating_details(review_count, rating) VALUES(?,?)");
        		p.setInt(1,  b.getReview_count());
//        		p.setInt(1,  1);
        		p.setDouble(2,  b.getRating());
        		p.execute();
        		
        		for(Category c: b.getCategories()) {
        			p = conn.prepareStatement("INSERT INTO Category(category_name, restaurant_id) VALUES(?, ?) ");
        			p.setString(1,  c.getAlias());
        			p.setString(2, b.getId());
        			p.execute();
        			
        			p = conn.prepareStatement("INSERT INTO Category(category_name, restaurant_id) VALUES(?, ?) ");
        			p.setString(1,  c.getTitle());
        			p.setString(2, b.getId());
        			p.execute();
        		}
        		
        		p = conn.prepareStatement("INSERT INTO Restaurant_details(image_url, address, phone_no, estimated_price, yelp_url) VALUES(?, ?, ?, ?, ?)");
        		p.setString(1, b.getImage_url());
        		p.setString(2, b.getLocation().get_display_address());
        		p.setString(3, b.getDisplay_phone());
        		p.setString(4, b.getPrice());
        		p.setString(5, b.getUrl());
        		p.execute(); //when i remove this line tables populate except Restaurant_details 
        		
        		p = conn.prepareStatement("INSERT INTO Restaurant(restaurant_id, restaurant_name, details_id, rating_id) VALUE(?, ?, ?, ?)");
        		p.setString(1, b.getId());
        		p.setString(2, b.getName());
        		p.setInt(3, count); //issue here - details and ratingis are 1 for all 
        		p.setInt(4, count); //issue here
        		p.execute();
        		
        		count++;
        		
        		
        	}
//        	ArrayList<Business> bus = getBusinesses(keyWord, sort, searchType);
//        	for(int i = 0; i < bus.size(); i++) {
//        		System.out.println(bus.get(i).getName());
//        	}
    		
        	
        }
        catch(ClassNotFoundException e){
        	e.printStackTrace();
        } 
        catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        
    }

    public static Business getBusiness(String id) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        //TODO return business based on id
        for(int i = 0; i < BusinessHelper.length; i++) {
    		if(BusinessHelper[i].getId() == id) {
    			return BusinessHelper[i];
    		}
    	}
        return null;
    }

    /**
     * @param keyWord    the search keyword
     * @param sort       the sort option (price, review count, rating)
     * @param searchType search in category or name
     * @return the list of business matching the criteria
     * @throws SQLException 
     */
    public static ArrayList<Business> getBusinesses(String keyWord, String sort, String searchType){
        ArrayList<Business> busisnesses = new ArrayList<Business>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
//            Class.forName("com.mysql.cj.jdbc.Driver"); //DO I NEED THIS 
        	String db = "jdbc:mysql://localhost:3306/restaurant_data?serverTimezone=UTC";
        	String name = "root";
        	String password = "root";
        	Connection conn = DriverManager.getConnection(db, name, password); //connect to SQL
        	
        //TODO get list of business based on the param
        
        //SEARCH TYPE
        String categorySQL = "";
        
        
        if(searchType.contentEquals("category")) {
        	
        		categorySQL = "SELECT r.restaurant_id, c.category_name, rd.rating, rd.review_count, d.estimated_price \n";
        		categorySQL += "From Restaurant r, Category c, Restaurant_details d, Rating_details rd \n";
        		categorySQL += "WHERE c.category_name LIKE '%" + keyWord + "%' \n";
        		categorySQL += "AND r.rating_id = rd.rating_id \n";
        		categorySQL += "AND c.restaurant_id = r.restaurant_id \n";
        		categorySQL += "AND r.details_id = d.details_id \n";
        		categorySQL += "ORDER BY  "; //ADD THE SORT TYPE 
        	
        		
        }
        //r name 
        else {
        	categorySQL = "SELECT r.restaurant_id, r.restaurant_name, rd.rating, rd.review_count, d.estimated_price \n";
    		categorySQL += "From Restaurant r, Category c, Restaurant_details d, Rating_details rd \n";
    		categorySQL += "WHERE r.restaurant_name LIKE '%" + keyWord + "%' \n";
    		categorySQL += "AND r.rating_id = rd.rating_id \n";
    		categorySQL += "AND c.restaurant_id = r.restaurant_id \n";
    		categorySQL += "AND r.details_id = d.details_id \n";
    		categorySQL += "ORDER BY  "; //ADD THE SORT TYPE ?
        	
        }
        
        //sorting 
        
        if(sort.equals("price")) {
        	categorySQL += "d.estimated_price ASC";
        }
        else if(sort.equals("rating")) {
        	categorySQL += "rd.rating DESC";
        }
        else{
        	categorySQL += "rd.review_count DESC";
        }
        
        
        PreparedStatement p;
        p = conn.prepareStatement(categorySQL);
        ResultSet r = p.executeQuery();
        
        while(r.next()) { //adding businesses to bussinesses 
        	boolean ex = false;
        	
        	for(Business b: busisnesses) {
        		if(b.getId().equals(r.getString("restaurant_id"))) {
        			ex = true;
        		}
        	}
        	if(!ex) { //get to add business
        		for(Business b: BusinessHelper) {
        			if(b.getId().equals(r.getString("restaurant_id"))) {
        				busisnesses.add(b);
        				break;
        			}
        		}
        	}
        	
        }
//        System.out.println("BEGIN");
//    	for(int i = 0; i < busisnesses.size(); i++) {
//    		System.out.println(busisnesses.get(i).getName());
//    	}
    	
    	 return busisnesses;
        
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        return null;

    }
    
//    public static void main(String[] args) throws FileNotFoundException {
////    	RestaurantDataParser.Init("restaurant_data.json");
//    	Init("/Users/carolinesilva/Desktop/eclipse-testyspace/PA2/src/main/webapp/restaurant_data.json");
//    }
    
}

////Code adapted from https://stackoverflow.com/questions/23070298/get-nested-json-object-with-gson-using-retrofit
//class BusinessDeserializer implements JsonDeserializer<BusinessHelper> {
//    @Override
//    public BusinessHelper deserialize(JsonElement je, Type type, JsonDeserializationContext jdc) throws JsonParseException {
//        JsonElement content = je.getAsJsonObject();
//        return new Gson().fromJson(content, BusinessHelper.class);
//    }
//}