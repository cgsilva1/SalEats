import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.file.Matcher;

import java.io.IOException;
import java.io.Serial;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.regex.Pattern;

/**
 * Servlet implementation class RegisterDispatcher
 */
@WebServlet("/RegisterDispatcher")
public class RegisterDispatcher extends HttpServlet {
    @Serial
    private static final long serialVersionUID = 1L;
    private static final String url = "jdbc:mysql://localhost:3306/PA2Users";

    /**
     * Default constructor.
     */
    public RegisterDispatcher() {
    }
    public class PasswordException extends Exception{
    	public PasswordException(String name) {
    		super(name);
    	}
    }
    public class EmailException extends Exception{
    	public EmailException(String email) {
    		super(email);
    	}
    }
    public class NameException extends Exception{
    	public NameException(String name) {
    		super(name);
    	}
    }


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     * response)
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //TODO
    	String email = request.getParameter("email");
    	String name = request.getParameter("name");
    	String password = request.getParameter("password");
    	String confirmP = request.getParameter("Cpassword");
    	
    	//ALL CHECKS AND IF ALL DONT HIT THEN ENTER INTO TABLE 
//    	String regex = "^(.+)@(//S+)$";
//		Pattern pattern = Pattern.compile(regex);
		String emailPattern = "^[a-zA-Z0-9_+&*-]+(?:\\."
	            + "[a-zA-Z0-9_+&*-]+)*@"
	            + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
	            + "A-Z]{2,7}$";
		String namePattern = "^[ A-Za-z]+$";

        	
//        	System.out.println(name);
//        	System.out.println(email);
//        	System.out.println(password);
        	
        	//String sqlInsert = "INSERT INTO user (name, email, password) VALUES (?, ?, ?)";
        	
        	try {
        		//connect to SQL
    			Class.forName("com.mysql.cj.jdbc.Driver");
    			String db = "jdbc:mysql://localhost:3306/userInfo?serverTimezone=UTC";
            	String user = "root";
            	String pw = "root";
            	Connection conn = DriverManager.getConnection(db, user, pw); 
            	
            	PreparedStatement p;
            	

            	//passwords do not match
            	if(!password.equals(confirmP)) { //NOT PRINTING 
            		//System.out.println("<span>Passwords do not match</span>"); //works but needs to print on website and stay on register page 
            		throw new PasswordException(password);
            	}
            	//not a valid email case
            	else if(!email.matches(emailPattern)) {
            		//System.out.println("<span>Email is not correct format</span>"); //works  
            		throw new EmailException(email);
            	}
            	else if(!name.matches(namePattern)) {
            		throw new NameException(email);
            	}
            	//account exisst (email is in user table)
//            	else if(conn.prepareStatement("EXISTS (SELECT * FROM email WHERE id = '%email%')") != null ) {
////            		SELECT * FROM table_name WHERE col_name LIKE '%email%'; //sql query statement 
//            		System.out.println("<span>Account already exists</span>");
//            	}
            	else {
            	
        
            	p = conn.prepareStatement("SET SQL_SAFE_UPDATES = 0;"); //safe updates 
            	p.execute();
            	
            	//insert user data to table
            	p = conn.prepareStatement("INSERT INTO user_details(email, name, password) VALUES (?, ?, ?)");
            	p.setString(1, email);
            	p.setString(2, name);
            	p.setString(3, password);
            	int row = p.executeUpdate();
            	
//            	System.out.println(String.format("Number of rows affected %d", row));
            	
            	//cookie
        		name = name.replace(" ", "=");
        		Cookie chocoChip = new Cookie("username", name);
        		response.addCookie(chocoChip);
        		
    	    	chocoChip.setMaxAge(60*60);
            	
            	response.sendRedirect("index.jsp");
            	
            	}
            	
    		} catch (ClassNotFoundException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		} catch (SQLException e) {
    			// TODO Auto-generated catch block
    			request.setAttribute("error", "Account with this email already exists");
    			getServletContext().getRequestDispatcher("/auth.jsp").forward(request,  response);
    		} catch(PasswordException e) {
    			request.setAttribute("error", "Passwords don't match");
    			getServletContext().getRequestDispatcher("/auth.jsp").forward(request,  response);
    		} catch(EmailException e) {
    			request.setAttribute("error", "Email format is not valid");
    			getServletContext().getRequestDispatcher("/auth.jsp").forward(request,  response);
//    		} catch(SQLException e) {
//    			request.setAttribute("error", "Account with this emial already exists");
//    			getServletContext().getRequestDispatcher("/auth.jsp").forward(request,  response);
//    		} 
    		} catch(NameException e) {
        		request.setAttribute("error", "Name format is not valid");
        		getServletContext().getRequestDispatcher("/auth.jsp").forward(request,  response);
    		} catch(Exception e) {
    			response.sendRedirect("auth.jsp");
    		}
        	
        	
        
        	
//        	RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
//    		dispatcher.forward(request, response);

    	}
    	

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     * response)
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}
