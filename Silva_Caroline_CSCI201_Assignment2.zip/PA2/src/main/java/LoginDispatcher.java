import javax.servlet.ServletException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.Serial;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Servlet implementation class LoginDispatcher
 */
@WebServlet("/LoginDispatcher")
public class LoginDispatcher extends HttpServlet {
    @Serial
    private static final long serialVersionUID = 1L;

   
    public class EmailException extends Exception{
		private static final long serialVersionUID = 1L;

		public EmailException(String email) {
    		super(email);
    	}
    }
    public class PasswordException extends Exception{
		private static final long serialVersionUID = 1L;

		public PasswordException(String name) {
    		super(name);
    	}
    }
    
    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     * response)
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //TODO
    	response.setContentType("text/html");
		

		String naL = request.getParameter("name");
    	String emL = request.getParameter("email");
    	String pwL = request.getParameter("password");
    	String sqlP;
    	String sqlE;
    
    	
    	String emailPattern = "^[a-zA-Z0-9_+&*-]+(?:\\."
	            + "[a-zA-Z0-9_+&*-]+)*@"
	            + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
	            + "A-Z]{2,7}$";
    	
    	//go to table and get name associated with the email
    	//make that name into a cookie 
    	//connect to SQL
    	try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String db = "jdbc:mysql://localhost:3306/userInfo?serverTimezone=UTC";
	    	String user = "root";
	    	String pw = "root";
	    	Connection conn = DriverManager.getConnection(db, user, pw); 
	    	PreparedStatement p;
	    	PreparedStatement gp;
	    	
	    	String sqlStr = "SELECT * FROM user_details WHERE email=?";
	    	p = conn.prepareStatement(sqlStr);
	    	p.setString(1, emL);
	    	ResultSet r = p.executeQuery();
	    	
	    	
	    	//NEED TO CHECK IF THE EMAIL USED TO LOGIN WITH GOOGLE EXITS IN THE TABLE 
	    	//could we create another result set and in if below check r.next() || g.next()
	    	
	    	//CHECK EMAIL IS VALID
//    		//not a valid email case
        	if(!emL.matches(emailPattern)) {
//        		System.out.println("<span>Email is not correct format</span>");  //works
//        		response.sendRedirect("auth.jsp"); 
        		throw new EmailException(emL);
        	}
//        	else if(conn.prepareStatement("EXISTS (SELECT * FROM email WHERE id = '%email%')") != null ) {
//	//    		SELECT * FROM table_name WHERE col_name LIKE '%email%'; //sql query statement 
//	    		//System.out.println("<span>Account does not exists, need to Register</span>"); //no account with this email so cant login 
//        		//System.out.println("EXISTS");
//	    		//response.sendRedirect("auth.jsp"); 
//        		throw new SQLException();
//        	}
        
        	
        	if(r.next() ) { //|| g.next()
        		naL = r.getString("name");
        		sqlP = r.getString("password");
        		sqlE = r.getString("email");
        		if(!pwL.equals(sqlP)) {
        			throw new PasswordException(pwL);
        		}
        		
        		//cookie
        		naL = naL.replace(" ", "=");
        		Cookie chocoChip = new Cookie("username", naL);
        		response.addCookie(chocoChip);
        		
    	    	chocoChip.setMaxAge(60*60);
        		response.sendRedirect("index.jsp");
        	}
        	
	    	else { //email matches and email exists in table 
	    		throw new SQLException();
	    	}
//	    
        
    	}
    	catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
			request.setAttribute("error", "Account with this email does not exists, Please Register");
			getServletContext().getRequestDispatcher("/auth.jsp").forward(request, response);
		} catch(EmailException e) {
			request.setAttribute("error", "Email format is not valid");
			getServletContext().getRequestDispatcher("/auth.jsp").forward(request, response);
		} 
    	catch(PasswordException e) {
			request.setAttribute("error", "Incorrect Password");
			getServletContext().getRequestDispatcher("/auth.jsp").forward(request, response);
		}
    	
    	//response.sendRedirect("auth.jsp");
 	
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     * response)
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
