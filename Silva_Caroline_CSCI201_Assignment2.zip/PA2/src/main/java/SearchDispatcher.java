import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Util.*;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serial;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;


/**
 * Servlet implementation class SearchDispatcher
 */
@WebServlet("/SearchDispatcher")
public class SearchDispatcher extends HttpServlet {
    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Default constructor.
     */
    public SearchDispatcher() {
    }

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
//        ServletContext servletContext = getServletContext();
        // TODO get json file as stream, Initialize RestaurantDataParser by calling its initialize method
//        RestaurantDataParser.Init("resturant_data.json");
//        InputStream stream = servletContext.getResourceAsStream(Constant.FileName);
//    	Scanner s = new Scanner(stream).useDelimiter("\\A");
//    	String result = s.hasNext() ? s.next() : "";
    	try {
        	RestaurantDataParser.Init(Constant.FileName);
        	//		RestaurantDataParser.Init("/Users/carolinesilva/Desktop/eclipse-testyspace/PA2/src/main/java/Util/restaurant_data.json");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO
//    	request.getRequestDispatcher("search.jsp").forward(request, response);
//    	response.setContentType("text/html;charset=UTF-8");
//    	request.getRequestDispatcher("search.jsp").forward(request, response); //not going 
    	
    	String keyWord = (String)request.getParameter("search");
    	String sort = (String)request.getParameter("btn");
    	String searchType = (String)request.getParameter("categories");
    	
    	//ArrayList<Business> results = RestaurantDataParser.Init("/Users/carolinesilva/Desktop/eclipse-testyspace/PA2/src/main/webapp/restaurant_data.json", keyWord, sort, searchType);
    	
		ArrayList<Business> results = RestaurantDataParser.getBusinesses(keyWord, sort, searchType);
		
		
		request.setAttribute("searchData", results);  
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/search.jsp");
		dispatcher.forward(request, response);
		
//			RequestDispatcher dispatcher = request.getRequestDispatcher("search.jsp");
//			dispatcher.forward(request, response);

		
//		System.out.println("start \n\n");
//		for(int i = 0; i < results.size(); i++) {
//			System.out.println(results.get(i).getName()); //when i run shows results is null 
//			
//		}   
//		System.out.println("end");
    	
    	
    }
    

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }
}