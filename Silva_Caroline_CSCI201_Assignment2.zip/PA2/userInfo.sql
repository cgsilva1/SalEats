DROP DATABASE IF EXISTS userInfo;
CREATE DATABASE userInfo;
USE userInfo;

CREATE TABLE `user_details` (
  `email` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
